//
//  ConfigViewController.m
//  Purchase Receipt
//
//  Created by Nupin Pillai on 12/01/15.
//  Copyright (c) 2015 Nupin Pillai. All rights reserved.
//

#import "ConfigViewController.h"

@implementation ConfigViewController

@end

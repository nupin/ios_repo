//
//  OrderCell.h
//  barcodeReader
//
//  Created by Madhumathi Karthikeyan on 03/01/14.
//

#import <UIKit/UIKit.h>

@protocol TouchDelegateForOrderCell <NSObject> //this delegate is fired each time you clicked the cell

- (void)touchedTheCell:(UITextField *)txtField :(NSString*)qty;

@end

@interface OrderCell : UITableViewCell<UITextFieldDelegate>

@property (strong, nonatomic) UILabel *itemlbl;
@property (strong, nonatomic) UILabel *descLbl;
@property (strong, nonatomic) UITextField *qtyTxt;
@property(nonatomic, assign)id<TouchDelegateForOrderCell> delegate;

@end
